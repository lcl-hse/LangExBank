import { createFile, createFileFromString } from '../file/File';

export {
  createFile,
  createFileFromString
};
