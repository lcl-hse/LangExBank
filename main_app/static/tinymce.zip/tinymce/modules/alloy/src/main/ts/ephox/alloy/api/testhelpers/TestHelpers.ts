// Test code - should eventually move to a separate project
import * as GuiSetup from './GuiSetup';
import TestStore from './TestStore';

export default {
  GuiSetup,
  TestStore
};